
#include "tree.h"

// creating tree structure according to pattern specified
node *createPatternTree(char *rootname, char *pattern, char *flag)
{
	node *rootNode = createTreeNode(rootname);
	rootNode->isrootNode = 1;
	rootNode->inner_ptr = createPatternTree_1(rootname, pattern, flag);
	rootNode->info.fpath = ".";
	return rootNode;
}

node *createPatternTree_1(char *rootname, char *pattern, char *flag)
{
	node *p = NULL, *q = NULL;
	node *t_start = NULL;

	char name[1000];
	struct dirent *dr = NULL;
	DIR *dir = opendir(rootname);
	if (!dir)
	{
		printf("Failed to open %s...\n", rootname);
		return NULL;
	}
	int k;

	while ((dr = readdir(dir)) != NULL)
	{

		// traversing only
		if ((dr->d_type) == DT_DIR || k)
		{
			if (strcmp((dr->d_name), ".") != 0 && strcmp((dr->d_name), "..") != 0)
			{
				p = createTreeNode(dr->d_name);
			}
			else
			{
				p = NULL;
				continue;
			}

			if (!q)
				t_start = p;
			else
				q->next_ptr = p;

			if ((dr->d_type) == DT_DIR)
			{
				p->isdir = 1;
				strcpy(name, rootname);

				p->inner_ptr = createPatternTree_1(strcat((strcat(name, "/")), dr->d_name), pattern, flag);
				p->info.fsize = get_Size(name);
				// printf("%s\n", name);
				strcpy(p->info.fpath, name);
				strcpy(p->info.fuser_name, get_username(name));
				strcpy(name, rootname);
			}
			else
			{
				p->isdir = 0;
				p->inner_ptr = NULL;

				strcpy(name, rootname);
				strcat((strcat(name, "/")), dr->d_name);
				p->info.fsize = get_Size(name);

				// printf("%s\n", name);
				strcpy(p->info.fpath, name);
				strcpy(p->info.fuser_name, get_username(name));
				strcpy(name, "");
			}

			q = p;
		}
	}
	return t_start;
}
